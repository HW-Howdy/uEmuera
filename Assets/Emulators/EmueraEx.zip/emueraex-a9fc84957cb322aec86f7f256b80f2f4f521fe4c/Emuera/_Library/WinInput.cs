﻿using System;
using System.Runtime.InteropServices;

namespace MinorShift._Library
{
	internal sealed class WinInput
	{
		[System.Runtime.InteropServices.DllImport("user32.dll")]
		public static extern short GetKeyState(int nVirtKey);
	}
}