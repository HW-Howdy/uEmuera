﻿using System.Drawing;

using XEraEmulator.Translation.EzTrans;

namespace XEraEmulator.GameView
{
	/// <summary>
	/// 描画の最小単位
	/// </summary>
	abstract class AConsoleDisplayPart
	{
		public bool Error { get; protected set; }

		private string _originalStr, _translatedStr;

		public string Str
		{
			get {
				if (EzTrans.IsMachineTranslateEnabled)
					return _translatedStr;
				else
					return _originalStr;
			}

			protected set
			{
				_originalStr = value;

				if (EzTrans.IsMachineTranslateEnabled)
					_translatedStr = Riey.EZTrans.TranslateXP.Translate(_originalStr);
			}
		}

		public string AltText { get; protected set; }
		public int PointX { get; set; }
		public float XsubPixel { get; set; }
		public float WidthF { get; set; }
		public int Width { get; set; }
		public virtual int Top { get { return 0; } }
		public virtual int Bottom { get { return Config.FontSize; } }
		public abstract bool CanDivide { get; }

		public abstract void DrawTo(Graphics graph, int pointY, bool isSelecting, bool isBackLog, TextDrawingMode mode);
		public abstract void GDIDrawTo(int pointY, bool isSelecting, bool isBackLog);

		public abstract void SetWidth(StringMeasure sm, float subPixel);
		public override string ToString()
		{
			if (Str == null)
				return "";
			return Str;
		}
	}

	/// <summary>
	/// 色つき
	/// </summary>
	abstract class AConsoleColoredPart : AConsoleDisplayPart
	{
		protected Color Color { get; set; }
		protected Color ButtonColor { get; set; }
		protected bool colorChanged;
	}
}
