﻿using System.Text;

using Newtonsoft.Json;

namespace XEraEmulator
{
	public sealed class EzEmueraSetting
	{
		public EzEmueraSetting()
		{
			ReadEncodingCode = 932;
		}

		public int ReadEncodingCode { get; set; }

		[JsonIgnore]
		public Encoding ReadEncoding => Encoding.GetEncoding(ReadEncodingCode);

		public string EzTransPath { get; set; }
	}
}
