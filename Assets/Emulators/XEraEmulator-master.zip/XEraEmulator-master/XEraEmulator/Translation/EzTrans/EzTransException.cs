﻿using System;

namespace XEraEmulator.Translation.EzTrans
{
	internal class EzTransException : Exception
	{
		public int Code { get; }

		public EzTransException(string message, int code) : base(message)
		{
			Code = code;
		}

		public override string ToString() => $"{base.ToString()}\n\nCode : {Code}";
	}
}
