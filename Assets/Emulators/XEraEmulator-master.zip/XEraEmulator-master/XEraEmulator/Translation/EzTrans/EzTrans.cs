﻿using System;
using System.IO;

using Newtonsoft.Json;

using Riey.EZTrans;

namespace XEraEmulator.Translation.EzTrans
{
	internal class EzTrans : IDisposable
	{
		private const string CacheFile = "cache.dat";
		private const string UserDic = "userdic.json";

		public static bool IsInitialized { get => TranslateXP.IsInitialized; }

		//TODO: Separate into somewhere (but not here)
		public static bool IsMachineTranslateEnabled { get => ConfigData.Instance.GetConfigItem(ConfigCode.MachineTranslate).GetValue<bool>() && IsInitialized; }

		public static EzTrans Instance { get; } = new EzTrans();

		public void Initialize()
		{
			if (string.IsNullOrEmpty(GetTranslatorPath()))
				throw new ArgumentException("EzTrans Path not designated.");
			else
			{
				if (File.Exists(CacheFile))
					TranslateXP.LoadCache(CacheFile);
				else
					TranslateXP.LoadCache(null);

				if (File.Exists(UserDic))
					TranslateXP.UserDic = JsonConvert.DeserializeObject<UserDictionary>(File.ReadAllText(UserDic));
				else
					TranslateXP.UserDic = new UserDictionary();

				int code = TranslateXP.Initialize(GetTranslatorPath());
				if (code != 0)
					throw new EzTransException(string.Empty, code);
			}
		}

		public void Dispose()
		{
			TranslateXP.SaveCache(CacheFile);
			TranslateXP.Terminate();
			File.WriteAllText(UserDic, JsonConvert.SerializeObject(TranslateXP.UserDic, Formatting.Indented));
		}

		private string GetTranslatorPath()
		{
			return ConfigData.Instance.GetConfigItem(ConfigCode.MachineTranslatorPath).GetValue<string>();
		}
	}
}
