﻿
using XEraEmulator.GameData.Expression;

namespace XEraEmulator.Sub
{
	internal abstract class Word
	{
		public abstract char Type { get; }
		public bool IsMacro = false;
		public virtual void SetIsMacro()
		{
			IsMacro = true;
		}
	}

	internal sealed class NullWord : Word
	{
		public NullWord() { }
		public override char Type { get { return '\0'; } }
		public override string ToString()
		{
			return "/null/";
		}
	}

	internal sealed class IdentifierWord : Word
	{
		public IdentifierWord(string s) { Code = s; }

		public string Code { get; }
		public override char Type { get { return 'A'; } }
		public override string ToString()
		{
			return Code;
		}
	}

	internal sealed class LiteralIntegerWord : Word
	{
		public LiteralIntegerWord(long i) { Int = i; }

		public long Int { get; }
		public override char Type { get { return '0'; } }
		public override string ToString()
		{
			return Int.ToString();
		}
	}

	internal sealed class LiteralStringWord : Word
	{
		public LiteralStringWord(string s) { Str = s; }

		public string Str { get; }
		public override char Type { get { return '\"'; } }
		public override string ToString()
		{
			return "\"" + Str + "\"";
		}
	}


	internal sealed class OperatorWord : Word
	{
		public OperatorWord(OperatorCode op) { Code = op; }

		public OperatorCode Code { get; }
		public override char Type { get { return '='; } }
		public override string ToString()
		{
			return Code.ToString();
		}
	}

	internal sealed class SymbolWord : Word
	{
		public SymbolWord(char c) { code = c; }
		readonly char code;
		public override char Type { get { return code; } }
		public override string ToString()
		{
			return code.ToString();
		}
	}

	internal sealed class StrFormWord : Word
	{

		public StrFormWord(string[] s, SubWord[] SWT) { Strs = s; subwords = SWT; }

		readonly SubWord[] subwords;
		public string[] Strs { get; }
		public SubWord[] SubWords { get { return subwords; } }
		public override char Type { get { return 'F'; } }//@はSymbolがつかっちゃった

		public override void SetIsMacro()
		{
			IsMacro = true;
			foreach (SubWord subword in SubWords)
			{
				subword.SetIsMacro();
			}
		}
	}


	internal sealed class TermWord : Word
	{
		public TermWord(IOperandTerm term) { this.Term = term; }

		public IOperandTerm Term { get; }
		public override char Type { get { return 'T'; } }
	}

	internal sealed class MacroWord : Word
	{
		public MacroWord(int num) { this.Number = num; }

		public int Number { get; }
		public override char Type { get { return 'M'; } }
		public override string ToString()
		{
			return "Arg" + Number.ToString();
		}
	}





}
