﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;

using XEraEmulator.Native;
using XEraEmulator.Properties;
using XEraEmulator.Translation.EzTrans;

namespace XEraEmulator
{
	static class Program
	{
		[STAThread]
		static void Main(string[] args)
		{
			ExeDir = Sys.ExeDir;
			CsvDir = ExeDir + "csv\\";
			ErbDir = ExeDir + "erb\\";
			DebugDir = ExeDir + "debug\\";
			DatDir = ExeDir + "dat\\";
			ContentDir = ExeDir + "resources\\";
			ExeName = Path.GetFileNameWithoutExtension(Sys.ExeName);


			int argsStart = 0;
			if ((args.Length > 0) && (args[0].Equals("-DEBUG", StringComparison.CurrentCultureIgnoreCase)))
			{
				argsStart = 1;
				debugMode = true;
			}
			if (args.Length > argsStart)
				AnalysisMode = true;

			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			ConfigData.Instance.LoadConfig();

			if (ConfigData.Instance.GetConfigItem(ConfigCode.MachineTranslate).GetValue<bool>())
			{
				try
				{
					EzTrans.Instance.Initialize();
				}
				catch (Exception e)
				{
					MessageBox.Show($"{Resources.EzTransInitializeFailure}\n{e}", Resources.Error);
				}
			}

			if ((!Config.AllowMultipleInstances) && (Sys.PrevInstance()))
			{
				MessageBox.Show(Resources.ProgramAlreadyExecuted, Resources.DuplicateExecute);
				return;
			}
			else if (!Directory.Exists(CsvDir))
			{
				MessageBox.Show(Resources.CSVNotExists);
				return;
			}
			else if (!Directory.Exists(ErbDir))
			{
				MessageBox.Show(Resources.ERBNotExists);
				return;
			}

			if (debugMode)
			{
				ConfigData.Instance.LoadDebugConfig();
				if (!Directory.Exists(DebugDir))
				{
					try
					{
						Directory.CreateDirectory(DebugDir);
					}
					catch
					{
						MessageBox.Show(Resources.DebugInitializeFailed);
						return;
					}
				}
			}

			if (AnalysisMode)
			{
				AnalysisFiles = new List<string>();
				for (int i = argsStart; i < args.Length; i++)
				{
					if (!File.Exists(args[i]) && !Directory.Exists(args[i]))
					{
						MessageBox.Show(Resources.FileOrDirectoryNotExists);
						return;
					}
					if ((File.GetAttributes(args[i]) & FileAttributes.Directory) == FileAttributes.Directory)
					{
						List<KeyValuePair<string, string>> fnames = Config.GetFiles(args[i] + "\\", "*.ERB");
						for (int j = 0; j < fnames.Count; j++)
						{
							AnalysisFiles.Add(fnames[j].Value);
						}
					}
					else
					{
						if (Path.GetExtension(args[i]).ToUpper() != ".ERB")
						{
							MessageBox.Show(Resources.InvalidERBFileExtension);
							return;
						}
						AnalysisFiles.Add(args[i]);
					}
				}
			}

			MainWindow win = null;
			while (true)
			{
				StartTime = WinmmTimer.TickCount;
				using (win = new MainWindow())
				{
					Application.Run(win);
					Content.AppContents.UnloadContents();
					if (!Reboot)
						break;

					RebootWinState = win.WindowState;
					if (win.WindowState == FormWindowState.Normal)
					{
						RebootClientY = win.ClientSize.Height;
						RebootLocation = win.Location;
					}
					else
					{
						RebootClientY = 0;
						RebootLocation = new Point();
					}
				}

				ParserMediator.ClearWarningList();
				ParserMediator.Initialize(null);
				GlobalStatic.Reset();
				Reboot = false;
				ConfigData.Instance.ReLoadConfig();
			}

			if (EzTrans.IsInitialized)
				EzTrans.Instance.Dispose();
		}

		/// <summary>
		/// 実行ファイルのディレクトリ。最後に\を付けたstring
		/// </summary>
		public static string ExeDir { get; private set; }
		public static string CsvDir { get; private set; }
		public static string ErbDir { get; private set; }
		public static string DebugDir { get; private set; }
		public static string DatDir { get; private set; }
		public static string ContentDir { get; private set; }
		public static string ExeName { get; private set; }

		public static bool Reboot = false;
		//public static int RebootClientX = 0;
		public static int RebootClientY = 0;
		public static FormWindowState RebootWinState = FormWindowState.Normal;
		public static Point RebootLocation;

		public static bool AnalysisMode = false;
		public static List<string> AnalysisFiles = null;

		public static bool debugMode = false;
		public static bool DebugMode { get { return debugMode; } }


		public static uint StartTime { get; private set; }

	}
}